/* *****************************************************************************
	* P.H.2024: simon.h
	* blink practica 2 de proyecto hardware 2024
	* Nekane Diaz Montoya   870795	
	* Jorge Hernandez Aznar 872838
 */

#ifndef SIMON
#define SIMON

#include "rt_evento_t.h"
#include <stdint.h>

void simon_iniciar(void);

void simon_tratar(EVENTO_T evento, uint32_t aux);

#endif
