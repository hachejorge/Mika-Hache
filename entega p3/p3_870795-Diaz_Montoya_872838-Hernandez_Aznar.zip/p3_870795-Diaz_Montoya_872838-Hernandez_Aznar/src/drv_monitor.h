#include <stdint.h>

uint32_t drv_monitor_iniciar(void);

void drv_monitor_marcar(uint32_t id);

void drv_monitor_desmarcar(uint32_t id);

